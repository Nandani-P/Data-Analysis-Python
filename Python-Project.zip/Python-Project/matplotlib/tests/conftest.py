from matplotlib.testing.conftest import (mpl_test_settings,
                                         mpl_image_comparison_parameters,
                                         pytest_configure, pytest_unconfigure,
                                         pd)
